package com.example.alarm_12;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class Scheduled_end extends Fragment {

    private View view;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.scheduled_end, container, false);

        String[] endtime_list = getResources().getStringArray(R.array.endtime);
        Spinner endtime_spinner = (Spinner) view.findViewById(R.id.endtime);
        ArrayAdapter endtime_Adapter = new ArrayAdapter(getContext(), android.R.layout.simple_spinner_dropdown_item, endtime_list);
        endtime_Adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        endtime_spinner.setAdapter(endtime_Adapter);
        endtime_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                //끝나는 시간 선택시 실행할 작업
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                //끝나는 시간 선택이 안되면 실행할 작업
            }
        });

        return view;
    }
}