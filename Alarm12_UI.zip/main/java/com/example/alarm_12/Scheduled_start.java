package com.example.alarm_12;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;

public class Scheduled_start extends Fragment {

    private View view;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.scheduled_start, container, false);

        String[] ampm_list = getResources().getStringArray(R.array.ampm);
        Spinner ampm_spinner = (Spinner) view.findViewById(R.id.ampm);
        ArrayAdapter ampm_Adapter = new ArrayAdapter(getActivity(), android.R.layout.simple_spinner_dropdown_item, ampm_list);
        ampm_Adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        ampm_spinner.setAdapter(ampm_Adapter);
        ampm_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                //오전 오후 선택시 실행할 작업
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                //오전 오후 선택이 안되면 실행할 작업
            }
        });

        String[] hours_list = getResources().getStringArray(R.array.hours);
        Spinner hours_spinner = (Spinner) view.findViewById(R.id.hours);
        ArrayAdapter hours_Adapter = new ArrayAdapter(getActivity(), android.R.layout.simple_spinner_dropdown_item, hours_list);
        hours_Adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        hours_spinner.setAdapter(hours_Adapter);
        hours_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                //시간 선택시 실행할 작업
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                //시간 선택이 안되면 실행할 작업
            }
        });

        String[] minute_list = getResources().getStringArray(R.array.minute);
        Spinner minute_spinner = (Spinner) view.findViewById(R.id.minute);
        ArrayAdapter minute_Adapter = new ArrayAdapter(getActivity(), android.R.layout.simple_spinner_dropdown_item, minute_list);
        minute_Adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        minute_spinner.setAdapter(minute_Adapter);
        minute_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                //분 선택시 실행할 작업
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                //분 선택이 안되면 실행할 작업
            }
        });


        return view;
    }
}