package com.example.alarm_12;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

public class Alarm extends Fragment {

    private View view;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.alarm, container, false);

        //설정된 알람을 나타내기 위한 listview
        ListView listView = (ListView) view.findViewById(R.id.listview_alarm);
        AlarmAdapter adapter = new AlarmAdapter();
        listView.setAdapter(adapter);

        adapter.addItem("AM", "8", "20");

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                Intent intent = new Intent(getActivity(), Newalarm.class);
                startActivity(intent);
            }
        });
        return view;
    }
}