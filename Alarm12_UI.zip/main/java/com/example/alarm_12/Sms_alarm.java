package com.example.alarm_12;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Sms_alarm extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sms_alarm);

        Button btncancle = (Button) findViewById(R.id.btn_smscancle);
        btncancle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

                /*
            <!--    SMS 버튼  -->
    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:gravity="center">
        <Button
        android:layout_width="300dp"
        android:layout_height="wrap_content"
        android:text="SMS"
        android:textSize="40dp"
        android:id="@+id/sms_btn"></Button>
    </LinearLayout>

        //SMS 버튼 클릭시 새창
        Button sms_btn = view.findViewById(R.id.sms_btn);
        sms_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(), Sms_alarm.class);
                startActivity(intent);
            }
        });
    */
}
