package com.example.alarm_12;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    private BottomNavigationView bottomNavigationView;  // 바텀 네비게이션 뷰
    private FragmentManager fragmentManager;
    private FragmentTransaction fragmentTransaction;
    private Alarm alarm;
    private Scheduled_start scheduled_start;
    private Scheduled_end scheduled_end;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        alarm = new Alarm();
        scheduled_start = new Scheduled_start();
        scheduled_end = new Scheduled_end();

        bottomNavigationView = findViewById(R.id.bottom_navi);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.nav_alarm:
                        setFrag(0);
                        break;

                    case R.id.nav_scheduled_start:
                        setFrag(1);
                        break;

                    case R.id.nav_scheduled_end:
                        setFrag(2);
                        break;
                }
                return true;
            }
        });
        setFrag(0); // 첫 화면 지정 0:Alarm

    }

    // 화면 변환
    private void setFrag(int n) {
        fragmentManager = getSupportFragmentManager();
        fragmentTransaction = fragmentManager.beginTransaction();
        switch (n)  {
            case 0:
                fragmentTransaction.replace(R.id.frame, alarm);
                fragmentTransaction.commit();
                break;

            case 1:
                fragmentTransaction.replace(R.id.frame, scheduled_start);
                fragmentTransaction.commit();
                break;

            case 2:
                fragmentTransaction.replace(R.id.frame, scheduled_end);
                fragmentTransaction.commit();
                break;
        }
    }
}