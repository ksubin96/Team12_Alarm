package com.example.alarm_12;

public class AlarmData {
    private String ampm;
    private String hour;
    private String minute;

    public void setAmpm(String ampm) {
        this.ampm = ampm;
    }

    public void setHour(String hour) {
        this.hour = hour;
    }

    public void setMinute(String minute) {
        this.minute = minute;
    }

    public String getAmpm() {
        return this.ampm;
    }

    public String getHour() {
        return this.hour;
    }

    public String getMinute() {
        return this.minute;
    }
}
