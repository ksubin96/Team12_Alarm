package com.example.alarm_12;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import java.util.ArrayList;

public class AlarmAdapter extends BaseAdapter{
    private ArrayList<AlarmData> alarmdatalist = new ArrayList<AlarmData>();
    Context context;
    LayoutInflater inflater;

    public AlarmAdapter(){
   }

    @Override
    public int getCount() {
        return alarmdatalist.size();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final Context context = parent.getContext();

        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.alarmlist, parent, false);
        }

        // 화면에 표시될 View(Layout이 inflate된)으로부터 위젯에 대한 참조 획득
        TextView alarm_ampm = (TextView) convertView.findViewById(R.id.listview_ampm) ;
        TextView alarm_hour = (TextView) convertView.findViewById(R.id.listview_hour) ;
        TextView alarm_minute = (TextView) convertView.findViewById(R.id.listview_minute) ;

        // Data Set(listViewItemList)에서 position에 위치한 데이터 참조 획득
        AlarmData alarmData = alarmdatalist.get(position);


        // 아이템 내 각 위젯에 데이터 반영
        alarm_ampm.setText(alarmData.getAmpm());
        alarm_hour.setText(alarmData.getHour());
        alarm_minute.setText(alarmData.getMinute());


        return convertView;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public Object getItem(int i) {
        return alarmdatalist.get(i);
    }

    public void addItem(String ampm, String hour, String minute){
        AlarmData item = new AlarmData();
        item.setAmpm(ampm);
        item.setHour(hour);
        item.setMinute(minute);

        alarmdatalist.add(item);
    }
}
