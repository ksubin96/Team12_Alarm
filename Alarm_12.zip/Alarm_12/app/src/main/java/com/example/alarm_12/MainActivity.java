package com.example.alarm_12;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //하단 메뉴 버튼 클릭시 화면전환(Intent 사용)
        //예약실행 메뉴
        Button scheduled_strat_btn = findViewById(R.id.btn_start);
        scheduled_strat_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), scheduled_start.class);
                startActivity(intent);
            }
        });

        //예약종료 메뉴
        Button scheduled_end_btn = findViewById(R.id.btn_end);
        scheduled_end_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), scheduled_end.class);
                startActivity(intent);
            }
        });
    }
}