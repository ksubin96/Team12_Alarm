package com.example.alarm_12;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class scheduled_start extends AppCompatActivity{
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.scheduled_start);

        /*상단 Title 변경
        final TextView menu = findViewById(R.id.title);
        Button btn_start = findViewById(R.id.btn_start);
        btn_start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                menu.setText("예약실행");
            }
        });
        */

        //Spinner 처리
        Spinner ampmspinner = findViewById(R.id.ampm);
        ArrayAdapter ampmAdapter = ArrayAdapter.createFromResource(this, R.array.ampm, android.R.layout.simple_spinner_dropdown_item);
        ampmAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        ampmspinner.setAdapter(ampmAdapter);

        Spinner hoursspinner = findViewById(R.id.hours);
        ArrayAdapter hoursAdapter = ArrayAdapter.createFromResource(this, R.array.hours, android.R.layout.simple_spinner_dropdown_item);
        hoursAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        hoursspinner.setAdapter(hoursAdapter);

        Spinner minutespinner = findViewById(R.id.minute);
        ArrayAdapter minuteAdapter = ArrayAdapter.createFromResource(this, R.array.minute, android.R.layout.simple_spinner_dropdown_item);
        minuteAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        minutespinner.setAdapter(minuteAdapter);

    }
}
